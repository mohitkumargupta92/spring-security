package com.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class CommonServicesController {

	public CommonServicesController() {
		System.out.println("From controller");
	}

	@RequestMapping(value = "/login", method = RequestMethod.GET)
	public /* ModelAndView */String login() {
		/*
		 * ModelAndView model = new ModelAndView(); model.setViewName("login");
		 * 
		 * return model;
		 */
		return "login";
	}

	@RequestMapping(value = "/", method = RequestMethod.GET)
	public /* ModelAndView */String defaultPage() {
		/*
		 * ModelAndView model = new ModelAndView(); model.setViewName("login");
		 */

		return "success";
	}

}
