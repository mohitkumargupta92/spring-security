package com.demo.security;

public class CustomDAoAuthenticationProvider {

}
