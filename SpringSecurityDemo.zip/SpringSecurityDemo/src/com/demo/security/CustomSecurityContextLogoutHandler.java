package com.demo.security;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.security.core.Authentication;
import org.springframework.security.web.authentication.logout.SecurityContextLogoutHandler;

public class CustomSecurityContextLogoutHandler extends SecurityContextLogoutHandler{

	@Override
	public boolean isInvalidateHttpSession() {
		// TODO Auto-generated method stub
		return super.isInvalidateHttpSession();
	}

	@Override
	public void logout(HttpServletRequest arg0, HttpServletResponse arg1,
			Authentication arg2) {
		// TODO Auto-generated method stub
		super.logout(arg0, arg1, arg2);
	}

	@Override
	public void setInvalidateHttpSession(boolean invalidateHttpSession) {
		// TODO Auto-generated method stub
		super.setInvalidateHttpSession(invalidateHttpSession);
	}

}
