package com.demo.security;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.web.context.HttpRequestResponseHolder;
import org.springframework.security.web.context.HttpSessionSecurityContextRepository;

public class CustomSecurityContextRepository extends HttpSessionSecurityContextRepository{

	@Override
	public boolean containsContext(HttpServletRequest request) {
		// TODO Auto-generated method stub
		return super.containsContext(request);
	}

	@Override
	public SecurityContext loadContext(
			HttpRequestResponseHolder requestResponseHolder) {
		// TODO Auto-generated method stub
		return super.loadContext(requestResponseHolder);
	}

	@Override
	public void saveContext(SecurityContext context,
			HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub
		super.saveContext(context, request, response);
	}

	@Override
	public void setAllowSessionCreation(boolean allowSessionCreation) {
		// TODO Auto-generated method stub
		super.setAllowSessionCreation(allowSessionCreation);
	}

	@Override
	public void setCloneFromHttpSession(boolean cloneFromHttpSession) {
		// TODO Auto-generated method stub
		super.setCloneFromHttpSession(cloneFromHttpSession);
	}

	@Override
	public void setDisableUrlRewriting(boolean disableUrlRewriting) {
		// TODO Auto-generated method stub
		super.setDisableUrlRewriting(disableUrlRewriting);
	}

	@Override
	public void setSecurityContextClass(Class contextClass) {
		// TODO Auto-generated method stub
		super.setSecurityContextClass(contextClass);
	}

}
