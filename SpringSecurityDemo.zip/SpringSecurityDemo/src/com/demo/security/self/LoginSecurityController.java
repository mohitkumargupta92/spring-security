package com.demo.security.self;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class LoginSecurityController {

	@RequestMapping(value = "/login", method = RequestMethod.GET)
	public String loginFunction() {

		return "login";

	}

	@RequestMapping(value = "/welcome", method = RequestMethod.GET)
	public String welcomeFunction() {

		return "Welcome";

	}

}
