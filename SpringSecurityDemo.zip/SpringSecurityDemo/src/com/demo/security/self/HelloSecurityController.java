package com.demo.security.self;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
//@RequestMapping("/index")
public class HelloSecurityController {

	@RequestMapping(method = RequestMethod.GET, value = "/index")
	public String executeSecurity(ModelMap model) {

		model.addAttribute("message", "Spring Security Hello World");
		model.addAttribute("author", "By DineshOnJava.com");
		return "Welcome";

	}

}
