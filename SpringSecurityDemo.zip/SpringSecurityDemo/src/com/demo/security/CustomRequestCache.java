package com.demo.security;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.security.web.PortResolver;
import org.springframework.security.web.savedrequest.HttpSessionRequestCache;
import org.springframework.security.web.savedrequest.SavedRequest;

public class CustomRequestCache extends HttpSessionRequestCache{

	@Override
	public HttpServletRequest getMatchingRequest(HttpServletRequest request,
			HttpServletResponse response) {
		// TODO Auto-generated method stub
		return super.getMatchingRequest(request, response);
	}

	@Override
	public SavedRequest getRequest(HttpServletRequest currentRequest,
			HttpServletResponse response) {
		// TODO Auto-generated method stub
		return super.getRequest(currentRequest, response);
	}

	@Override
	public void removeRequest(HttpServletRequest currentRequest,
			HttpServletResponse response) {
		// TODO Auto-generated method stub
		super.removeRequest(currentRequest, response);
	}

	@Override
	public void saveRequest(HttpServletRequest arg0, HttpServletResponse arg1) {
		// TODO Auto-generated method stub
		super.saveRequest(arg0, arg1);
	}

	@Override
	public void setCreateSessionAllowed(boolean createSessionAllowed) {
		// TODO Auto-generated method stub
		super.setCreateSessionAllowed(createSessionAllowed);
	}

	@Override
	public void setJustUseSavedRequestOnGet(boolean justUseSavedRequestOnGet) {
		// TODO Auto-generated method stub
		super.setJustUseSavedRequestOnGet(justUseSavedRequestOnGet);
	}

	@Override
	public void setPortResolver(PortResolver portResolver) {
		// TODO Auto-generated method stub
		super.setPortResolver(portResolver);
	}

}
